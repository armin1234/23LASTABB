/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package primera;

/**
 *
 * @author estudiante
 */
public class PRIMERA {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        double A, B, C, x1, x2; 
Terminal.escribirStringln ("Introduzca el valor de a "); 
A=Terminal.leerDouble( ) ; 
Terminal.escribirStringln ("Introduzca el valor de b "); 
B=Terminal.leerDouble( ) ; 
Terminal.escribirStringln ("Introduzca el valor de c "); 
C=Terminal.leerDouble( ) ; 
if (A==0, B==0, C==0) // da error aquí 
{Terminal.escribirStringln ("x puede tomar cualquier valor")} 
else 
{if (A==0, B==0, C != 0) ; 
Terminal.escribirStringln ("no hay solucion posible") 
else 
{if (A==0, B != 0); 
{x1==x2== - C/B} 
else 
{double d = (B*B – (4*A*C)); // da error aquí 
if (d > 0); 
{x1= ((-B + Math.sqrt (d))/(2*A)); 
x2= ((-B - Math.sqrt (d))/(2*A)) } 
else 
{if (d==0); 
{x1=x2= - B/ (2*A) } 
else 
{d=Math.abs(d); 
x1= ((-B + Math.sqrt (d))/(2*A)); 
x2= ((-B - Math.sqrt (d))/(2*A))}}}}} 
Terminal.escribirStringln ("x1 = " + x1) ; 
Terminal.escribirStringln ("x2 = " + x2) ; 

} 
    }
    
}
